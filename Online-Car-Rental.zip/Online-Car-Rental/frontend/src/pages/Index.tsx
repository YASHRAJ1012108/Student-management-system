import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Clock, Star } from "lucide-react";
import Navbar from "@/components/ui/Navbar";

const Index = () => {
  const [user, setUser] = useState(() => {
    const userData = localStorage.getItem("user");
    return userData ? JSON.parse(userData) : null;
  });
  const navigate = useNavigate();

  const featuredCars = [
    {
      id: 1,
      name: "Toyota Camry",
      image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400",
      pricePerHour: 2500,
      seats: 5,
      transmission: "Automatic",
      rating: 4.8
    },
    {
      id: 2,
      name: "BMW X5",
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400",
      pricePerHour: 4500,
      seats: 7,
      transmission: "Automatic",
      rating: 4.9
    },
    {
      id: 3,
      name: "Mercedes C-Class",
      image: "https://images.unsplash.com/photo-1563720223185-11003d516935?w=400",
      pricePerHour: 3500,
      seats: 5,
      transmission: "Automatic",
      rating: 4.7
    }
  ];

  const handleBrowseCars = () => {
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f0f4ff] via-[#f8fafc] to-white">
      <Navbar />
      {/* Hero Section */}
      <section className="relative py-12 sm:py-16 md:py-20 px-2 sm:px-4 animate-fade-in-up">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-indigo-700 mb-4 sm:mb-6 animate-text-glow">
            Rent the Perfect Car for Your Journey
          </h1>
          <p className="text-base sm:text-lg md:text-xl text-gray-800 mb-6 sm:mb-8 max-w-3xl mx-auto animate-fade-in">
            Choose from our wide selection of premium vehicles. Affordable rates, reliable service, and flexible booking options. Start your adventure today!
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <Button size="lg" className="w-full sm:w-auto px-8 py-3 animate-bounce-slow" onClick={handleBrowseCars}>
              Browse Cars
            </Button>
            <Link to="/register" className="w-full sm:w-auto">
              <Button size="lg" className="w-full sm:w-auto px-8 py-3 bg-indigo-600 text-white font-bold hover:bg-indigo-700 animate-fade-in shadow-lg">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </section>
      {/* Features */}
      <section className="py-10 sm:py-16 bg-gray-50 animate-fade-in-up">
        <div className="max-w-7xl mx-auto px-2 sm:px-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-blue-600 text-center mb-8 sm:mb-12 animate-text-glow">Why Choose RentCar?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center hover:scale-105 transition-transform duration-300 animate-fade-in hover:bg-blue-50 hover:shadow-xl transition-all p-6 rounded-xl">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center animate-bounce-slow">
                <img src="/Logo.jpg" alt="Premium Fleet" className="h-8 w-8 rounded" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-indigo-700">Premium Fleet</h3>
              <p className="text-blue-500 text-sm sm:text-base">Well-maintained vehicles from top brands</p>
            </div>
            <div className="text-center hover:scale-105 transition-transform duration-300 animate-fade-in hover:bg-blue-50 hover:shadow-xl transition-all p-6 rounded-xl">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center animate-bounce-slow">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-indigo-700">24/7 Service</h3>
              <p className="text-blue-500 text-sm sm:text-base">Round-the-clock customer support</p>
            </div>
            <div className="text-center hover:scale-105 transition-transform duration-300 animate-fade-in hover:bg-blue-50 hover:shadow-xl transition-all p-6 rounded-xl">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center animate-bounce-slow">
                <img src="/Logo.jpg" alt="Best Rates" className="h-8 w-8 rounded" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold mb-2 text-indigo-700">Best Rates</h3>
              <p className="text-blue-500 text-sm sm:text-base">Competitive pricing with no hidden fees</p>
            </div>
          </div>
        </div>
      </section>
      {/* Featured Cars */}
      <section className="py-10 sm:py-16 animate-fade-in-up">
        <div className="max-w-7xl mx-auto px-2 sm:px-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-blue-600 text-center mb-8 sm:mb-12 animate-text-glow">Featured Vehicles</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {featuredCars.map((car) => (
              <Card key={car.id} className="overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-300 animate-fade-in rounded-xl">
                <div className="aspect-video overflow-hidden rounded-t-xl">
                  <img 
                    src={car.image} 
                    alt={car.name}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="flex justify-between items-center text-base sm:text-lg md:text-xl">
                    {car.name}
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm text-blue-600">{car.rating}</span>
                    </div>
                  </CardTitle>
                  <CardDescription>
                    <div className="flex flex-col sm:flex-row items-center sm:space-x-4 text-sm text-blue-500">
                      <span className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        {car.seats} seats
                      </span>
                      <span>{car.transmission}</span>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                    <div>
                      <span className="text-xl sm:text-2xl font-bold text-indigo-700">₹{car.pricePerHour}</span>
                      <span className="text-blue-500 ml-1">/hour</span>
                    </div>
                    <Link to="/login" className="w-full sm:w-auto">
                      <Button className="animate-bounce-slow w-full sm:w-auto">Book Now</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
      {/* Footer */}
      <footer className="bg-gray-900 text-gray-200 py-12 animate-fade-in">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <span className="text-2xl font-bold animate-text-glow text-white">RentCar</span>
              </div>
              <p className="text-gray-400">Your trusted car rental partner</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-blue-400">Services</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Car Rental</li>
                <li>Long-term Lease</li>
                <li>Driver Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-blue-400">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-blue-400">Contact</h4>
              <p className="text-gray-300">support@rentcar.com</p>
              <p className="text-gray-300">1-800-RENTCAR</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
