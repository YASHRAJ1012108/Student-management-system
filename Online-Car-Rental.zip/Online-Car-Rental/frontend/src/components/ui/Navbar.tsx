import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuLink,
} from "./navigation-menu";
import { Button } from "./button";

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/cars", label: "Browse Cars" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const location = useLocation();
  return (
    <header className="bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-500 shadow-lg sticky top-0 z-50 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <img
              src="/Logo.jpg"
              alt="Logo"
              className="h-12 w-12 rounded-full shadow-lg border-2 border-white animate-bounce-slow"
            />
            <span className="text-2xl font-extrabold text-white tracking-wide drop-shadow-lg animate-text-glow">
              RentCar
            </span>
          </div>
          <NavigationMenu>
            <NavigationMenuList>
              {navLinks.map((link) => (
                <NavigationMenuItem key={link.to}>
                  <NavigationMenuLink asChild>
                    <Link
                      to={link.to}
                      className={`px-4 py-2 rounded-md text-white font-medium transition-all duration-200 relative group ${
                        location.pathname === link.to
                          ? "bg-white/20 shadow-lg"
                          : "hover:bg-white/10 hover:scale-105"
                      }`}
                    >
                      <span className="relative z-10">{link.label}</span>
                      <span className="absolute left-0 bottom-0 w-full h-0.5 bg-white opacity-0 group-hover:opacity-100 group-hover:h-1 transition-all duration-300 rounded-full" />
                    </Link>
                  </NavigationMenuLink>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>
          <div className="flex space-x-3">
            <Link to="/login">
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 transition-all duration-200 shadow-md animate-fade-in"
              >
                Login
              </Button>
            </Link>
            <Link to="/register">
              <Button
                className="bg-white text-blue-600 font-bold hover:bg-blue-100 hover:scale-105 transition-all duration-200 shadow-md animate-fade-in"
              >
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

// Custom animations for hackathon wow effect (add to tailwind.config if needed):
// .animate-fade-in { animation: fadeIn 0.8s ease; }
// .animate-bounce-slow { animation: bounce 2s infinite; }
// .animate-text-glow { text-shadow: 0 0 8px #fff, 0 0 16px #6366f1; } 